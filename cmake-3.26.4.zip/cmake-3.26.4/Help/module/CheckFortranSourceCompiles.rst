.. cmake-module:: ../../Modules/CheckFortranSourceCompiles.cmake
