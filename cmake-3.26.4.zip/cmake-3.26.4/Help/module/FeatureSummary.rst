.. cmake-module:: ../../Modules/FeatureSummary.cmake
